
--Insert and Update Employee 
CREATE PROCEDURE Insertupdateemployee(@Id      INTEGER, 
                                       @Name    NVARCHAR(50), 
                                       @Age     INTEGER, 
                                       @State   NVARCHAR(50), 
                                       @Country NVARCHAR(50), 
                                       @Action  VARCHAR(10)) 
AS 
  BEGIN 
      IF @Action = 'Insert' 
        BEGIN 
            INSERT INTO employee 
                        (NAME, 
                         age, 
                         [state], 
                         country) 
            VALUES     (@Name, 
                        @Age, 
                        @State, 
                        @Country); 
        END 
      IF @Action = 'Update' 
        BEGIN 
            UPDATE employee 
            SET    NAME = @Name, 
                   age = @Age, 
                   [state] = @State, 
                   country = @Country 
            WHERE  employeeid = @Id; 
        END 
  END 
