--Delete Employee 
CREATE PROCEDURE Deleteemployee (@Id INTEGER) 
AS 
  BEGIN 
      DELETE employee 
      WHERE  employeeid = @Id; 
  END