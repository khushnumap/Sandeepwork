CREATE PROCEDURE Selectemployee 
AS 
  BEGIN 
      SELECT * 
      FROM   employee; 
  END 
